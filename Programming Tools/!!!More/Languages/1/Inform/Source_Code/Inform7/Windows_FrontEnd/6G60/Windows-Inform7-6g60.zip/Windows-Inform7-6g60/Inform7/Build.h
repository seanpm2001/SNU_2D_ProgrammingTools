#define BUILD_DATE "13th February 2011"
#define NI_BUILD "6G60"
