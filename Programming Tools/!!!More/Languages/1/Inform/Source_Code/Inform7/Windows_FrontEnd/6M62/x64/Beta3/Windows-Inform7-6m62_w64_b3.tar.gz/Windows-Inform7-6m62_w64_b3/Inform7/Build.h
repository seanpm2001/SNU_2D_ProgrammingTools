#define BUILD_DATE "1st November 2020"
#define NI_BUILD "6M62"
