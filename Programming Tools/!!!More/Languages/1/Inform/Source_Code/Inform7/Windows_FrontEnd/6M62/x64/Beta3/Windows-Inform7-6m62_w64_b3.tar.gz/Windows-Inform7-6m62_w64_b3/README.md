# Windows Inform 7

[Inform 7](http://inform7.com/) is the most widely used interactive fiction (i.e. text adventure game) authoring system available today. This repository contains the Windows front-end that represents the user interface that users of Inform work with:

![Windows Inform 7](Inform7.png)
