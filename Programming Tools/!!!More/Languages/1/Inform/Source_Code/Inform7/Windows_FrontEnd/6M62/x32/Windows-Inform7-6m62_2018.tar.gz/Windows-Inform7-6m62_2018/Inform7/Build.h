#define BUILD_DATE "6th February 2017"
#define NI_BUILD "6M62"
