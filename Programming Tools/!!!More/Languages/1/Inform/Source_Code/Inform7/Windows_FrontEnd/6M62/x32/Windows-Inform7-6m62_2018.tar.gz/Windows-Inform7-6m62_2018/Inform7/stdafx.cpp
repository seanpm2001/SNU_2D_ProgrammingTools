// stdafx.cpp : source file that includes just the standard includes
// Inform7.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

#if (_MSC_VER >= 1700)
#define COMPILE_MULTIMON_STUBS
#include <MultiMon.h>
#endif
