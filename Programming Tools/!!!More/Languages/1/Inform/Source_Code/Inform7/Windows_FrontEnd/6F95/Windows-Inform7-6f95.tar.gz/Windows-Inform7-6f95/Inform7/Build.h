#define BUILD_DATE "18th October 2010"
#define NI_BUILD "6F92"
