This is version 6.34 of the Inform compiler,
copyright (c) Graham Nelson 1993 - 2020
Full release notes and instructions are available at
http://www.ifarchive.org/indexes/if-archiveXinfocomXcompilersXinform6.html

