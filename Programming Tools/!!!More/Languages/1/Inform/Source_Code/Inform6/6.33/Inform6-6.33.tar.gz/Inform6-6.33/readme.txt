This is version 6.33 of the Inform compiler,
copyright (c) Graham Nelson 1993 - 2014
Full release notes and instructions are available at
http://www.ifarchive.org/indexes/if-archiveXinfocomXcompilersXinform6.html

