This is version 6.30 of the Inform compiler,
copyright (c) Graham Nelson 1993 - 2004
Full release notes and instructions are available at
http://www.inform-fiction.org
and
http://www.ifarchive.org/indexes/if-archiveXinfocomXcompilersXinform6.html