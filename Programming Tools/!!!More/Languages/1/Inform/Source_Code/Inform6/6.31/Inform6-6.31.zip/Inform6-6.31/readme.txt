This is version 6.31 of the Inform compiler,
copyright (c) Graham Nelson 1993 - 2006
Full release notes and instructions are available at
http://www.inform-fiction.org
and
http://www.ifarchive.org/indexes/if-archiveXinfocomXcompilersXinform6.html


This is a bug-fix update to Inform 6.30. The only changes between 6.30 and
6.31 are the application of the following patches:

C63001: Compiler overflows if too many properties
http://www.inform-fiction.org/patches/C63001.html

C63005: Backpatch errors in large V8 games
http://www.inform-fiction.org/patches/C63005.html

C63009: Various problems with PATHLEN
http://www.inform-fiction.org/patches/C63009.html

C63013: Complex 'if' crashes compiler
http://www.inform-fiction.org/patches/C63013.html

C63016: Bad code generation in veneer.c
http://www.inform-fiction.org/patches/C63016.html


